## History Website
Install steps:

1- Install Python 3.7<br>
2- Install pip<br>
3- Install requirements with command <code>pip install -r requirements.txt</code><br>
4- run <code>python manage.py migrate</code><br>
4- run <code>python manage.py createsuperuser</code><br>
5- open url <code>http://localhost:8000/add</code> for add all States at Province.json<br>
6- run with <code>python manage.py runserver</code>
